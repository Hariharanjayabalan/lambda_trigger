class GithubArchiveConf:
    BUCKET_NAME='hari-redshift123'
    FILE_NAME=''
    HOME_PATH='github/'